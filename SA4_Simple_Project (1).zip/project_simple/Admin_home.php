<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "db_userprivileges");
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if (!isset($_SESSION['accesslevel']) || $_SESSION['accesslevel'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Delete user
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM users WHERE id=$id");
    header("Location: Admin_home.php");
    exit();
}

// Enable/disable user
if (isset($_GET['toggle'])) {
    $id = (int)$_GET['toggle'];
    $result = mysqli_query($conn, "SELECT status FROM users WHERE id=$id");
    $row = $result ? mysqli_fetch_assoc($result) : null;
    if ($row) {
        $newstatus = ($row['status'] == 'active') ? 'disable' : 'active';
        mysqli_query($conn, "UPDATE users SET status='$newstatus' WHERE id=$id");
    }
    header("Location: Admin_home.php");
    exit();
}
?>
<html>
<head>
    <title>Admin Home</title>
</head>
<body>
    <div style="text-align:right;">
        Welcome <?php echo htmlspecialchars($_SESSION['firstname']); ?> |
        <a href="logout.php">Logout</a>
    </div>

    <h2>My Information</h2>
    <p>
        <a href="Admin_image.php">upload image</a> |
        <a href="Admin_changepass.php">Reset my password</a>
    </p>

    <h2>-Records-</h2>
    <p><a href="Admin_adduser.php">Add New User</a></p>

    <table border="1" cellpadding="5">
        <tr>
            <th>ID</th><th>First Name</th><th>Middle Name</th><th>Last Name</th>
            <th>Contact No.</th><th>Email</th><th>Birthday</th><th>Username</th>
            <th>Access Level</th><th>Status</th><th>Action</th>
        </tr>
        <?php
        $result = mysqli_query($conn, "SELECT * FROM users");
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . (int)$row['id'] . "</td>";
                echo "<td>" . htmlspecialchars($row['firstname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['middlename']) . "</td>";
                echo "<td>" . htmlspecialchars($row['lastname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['contactno']) . "</td>";
                echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                echo "<td>" . htmlspecialchars($row['birthday']) . "</td>";
                echo "<td>" . htmlspecialchars($row['username']) . "</td>";
                echo "<td>" . htmlspecialchars($row['accesslevel']) . "</td>";
                echo "<td><a href='Admin_home.php?toggle=" . (int)$row['id'] . "'>" . htmlspecialchars($row['status']) . "</a></td>";
                echo "<td><a href='Admin_adduser.php?id=" . (int)$row['id'] . "'>Edit</a> | ";
                echo "<a href='Admin_home.php?delete=" . (int)$row['id'] . "' onclick=\"return confirm('Delete this user?')\">Delete</a></td>";
                echo "</tr>";
            }
        }
        ?>
    </table>
</body>
</html>
